# @veyra/renderer

Reusable ES module extracted from Veyra Studio. No app or framework dependency.

See the source repository docs/API.md for API contracts and docs/CAPABILITIES.md for supported behavior.
